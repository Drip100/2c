# TrilhaprogEM_2023
Trabalhos desenvolvidos no decorrer de 2023.
